package LoginPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class GhostDriver {

	public static void main(String[] args) throws InterruptedException {
		
					WebDriver driver = new HtmlUnitDriver();
						
					driver.get("file://ndafile/GLC-G102/BDD/Selenium/login.html");
				    System.out.println("Page title is: " + driver.getTitle());      
				    Thread.sleep(10000);
				    driver.quit();
	}

}
