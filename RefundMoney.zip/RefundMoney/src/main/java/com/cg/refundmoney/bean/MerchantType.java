package com.cg.refundmoney.bean;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
