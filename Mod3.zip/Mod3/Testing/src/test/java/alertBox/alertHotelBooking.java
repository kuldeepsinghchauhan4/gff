package alertBox;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class alertHotelBooking {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/GLC-G102/BDD/Selenium/hotelbooking.html");
		Thread.sleep(500);
		driver.findElement(By.id("txtFirstName")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtFirstName")).sendKeys("kuldeep");
	    
		driver.findElement(By.id("txtLastName")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtLastName")).sendKeys("singh");
	    
		driver.findElement(By.id("txtEmail")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtEmail")).sendKeys("ksinghchauhan4@gmail.com");
	    
	    driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7896");
	    callAlert();
	    
	    
		driver.findElement(By.id("txtPhone")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtPhone")).sendKeys("7500800149");
	    
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("");
	    callAlert();
	    driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Delhi");
	    
	    Select drpCity=new Select(driver.findElement(By.name("city")));
	    drpCity.selectByIndex(0);
	   // driver.findElement(By.id("btnPayment")).click();
	    callAlert();
	    drpCity.selectByVisibleText("Pune");
	    
	   drpCity=new Select(driver.findElement(By.name("state")));
	    drpCity.selectByIndex(0);
	   // driver.findElement(By.id("btnPayment")).click();
	    callAlert();
	    drpCity.selectByVisibleText("Karnataka");
	    
	    drpCity=new Select(driver.findElement(By.name("persons")));
	    drpCity.selectByIndex(0);
	   // driver.findElement(By.id("btnPayment")).click();
	    callAlert();
	    drpCity.selectByVisibleText("2");
	    
	    driver.findElement(By.id("txtCardholderName")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtCardholderName")).sendKeys("kuldeepsingh");
	    
	    driver.findElement(By.id("txtDebit")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtDebit")).sendKeys("4514520103288740");
	    
	    driver.findElement(By.id("txtCvv")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtCvv")).sendKeys("256");
	    
	    driver.findElement(By.id("txtMonth")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtMonth")).sendKeys("07");
	    
	    driver.findElement(By.id("txtYear")).sendKeys("");
	    callAlert();
	    driver.findElement(By.id("txtYear")).sendKeys("25");
	    
	}

	
	
	public static void callAlert() throws InterruptedException {
		driver.findElement(By.id("btnPayment")).click();
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("alertMsg");
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		Thread.sleep(500);
	}
	
	
}
