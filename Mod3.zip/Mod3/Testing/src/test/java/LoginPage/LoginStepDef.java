package LoginPage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LoginPageBean.LoginPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {
	private WebDriver driver;
	private LoginPageFactory obj;
	 
	
	
		@Given("^User is on LoginPage$")
	public void user_is_on_LoginPage() throws Throwable {
		/*System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
		driver = new ChromeDriver();*/
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj= new LoginPageFactory(driver);
		driver.get("file://ndafile/GLC-G102/BDD/Selenium/login.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("LoginPage")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	obj.setPfuname("kuldeep");
	obj.setPfpwd("7500800");
	obj.setPfbutton();
	   
	}

	@Then("^navigate to LoginPage$")
	public void navigate_to_LoginPage() throws Throwable {
		driver.navigate().to("file://ndafile/GLC-G102/BDD/Selenium/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		//driver.close();
	}

	@When("^user leaves User Name blank$")
	public void user_leaves_User_Name_blank() throws Throwable {
	  obj.setPfuname(""); 
	  Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	obj.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves Password blank$")
	public void user_leaves_Password_blank() throws Throwable {
		obj.setPfuname("kuldeep"); 
		Thread.sleep(1000);
	  obj.setPfpwd(""); 
	  obj.setPfbutton();
	  String error=driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[3]/td[2]/input")).getText();
	  System.out.println("The error is:"+error);
	  Thread.sleep(1000);

	}
	
	@When("^user entering wrond details$")
public void user_entering_wrond_details() throws Throwable {
		obj.setPfuname("capg"); 
		Thread.sleep(1000);
	  obj.setPfpwd("cp123"); 
	  obj.setPfbutton();
	  Thread.sleep(1000);
}
	@When("^user entering correct details$")
	public void user_entering_correct_details() throws Throwable {
		obj.setPfuname("capgemini"); 
		Thread.sleep(1000);
	  obj.setPfpwd("capg1234"); 
	  obj.setPfbutton();
	  Thread.sleep(1000);
	}


}
