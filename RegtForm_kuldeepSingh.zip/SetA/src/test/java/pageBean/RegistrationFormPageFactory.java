package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationFormPageFactory {
	WebDriver driver;
	
	@FindBy(how=How.ID, using="usrID")
	@CacheLookup
	WebElement pfuserID;
	
	@FindBy(how=How.ID, using="pwd")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(how=How.ID, using="usrname")
	@CacheLookup
	WebElement pfusrname;
	
	@FindBy(how=How.ID, using="addr")
	@CacheLookup
	WebElement pfaddr;
	
	@FindBy(name="country")
	@CacheLookup
	WebElement pfcountry;
	
	@FindBy(name="zip")
	@CacheLookup
	WebElement pfzip;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(xpath="html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement pfsexMale;
	
	@FindBy(xpath="html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement pfsexFemale;
	
	@FindBy(name="en")
	@CacheLookup
	WebElement pfen;
	
	@FindBy(name="nonen")
	@CacheLookup
	WebElement pfnonen;
	
	@FindBy(name="desc")
	@CacheLookup
	WebElement pfdesc;
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement pfsubmit;
	
	
	
	public WebElement getPfuserID() {
		return pfuserID;
	}



	public void setPfuserID(String spfuserID) {
		pfuserID.sendKeys(spfuserID);
	}



	public WebElement getPfpwd() {
		return pfpwd;
	}



	public void setPfpwd(String spfpwd) {
		pfpwd.sendKeys(spfpwd);
	}



	public WebElement getPfusrname() {
		return pfusrname;
	}



	public void setPfusrname(String spfusrname) {
		pfusrname.sendKeys(spfusrname);
	}



	public WebElement getPfaddr() {
		return pfaddr;
	}



	public void setPfaddr(String spfaddr) {
		pfaddr.sendKeys(spfaddr);
	}



	public WebElement getPfcountry() {
		return pfcountry;
	}



	public void setPfcountry(String spfcountry) {
		Select drpcountry = new Select(pfcountry);
		drpcountry.selectByVisibleText(spfcountry);
	}



	public WebElement getPfzip() {
		return pfzip;
	}



	public void setPfzip(String spfzip) {
		pfzip.sendKeys(spfzip);
	}



	public WebElement getPfemail() {
		return pfemail;
	}



	public void setPfemail(String spfemail) {
		pfemail.sendKeys(spfemail);
	}



	public WebElement getPfsex() {
		return pfsexMale;
	}



	public void setPfsex(String spfsex) {
		if(spfsex=="Male")
		{
			pfsexMale.click();
		}
		else if(spfsex=="Female")
		{
			pfsexFemale.click();
		}
	}



	public WebElement getPfen() {
		return pfen;
	}



	public void setPfen(String spfen) {
		if(spfen=="Non English")
		{
			pfnonen.click();
		}
	 
	 
	}



	public WebElement getPfdesc() {
		return pfdesc;
	}



	public void setPfdesc(String spfdesc) {
		pfdesc.sendKeys(spfdesc);
	}



	public WebElement getPfsubmit() {
		return pfsubmit;
	}



	public void setPfsubmit() {
		pfsubmit.click();
	}



	public RegistrationFormPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
