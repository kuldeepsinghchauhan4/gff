package webDriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class workingWithForms {
public static void main(String[] args) throws InterruptedException {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file://ndafile/GLC-G102/BDD/WorkingWithForms.html");
	driver.findElement(By.id("txtUserName")).sendKeys("kuldeep12");
	driver.findElement(By.name("txtPwd")).sendKeys("igate");
	driver.findElement(By.className("Format")).sendKeys("igate");
	//try {
		Thread.sleep(1000);
	//} catch (Exception e) {
		// TODO Auto-generated catch block
		//System.out.println("some exception");
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("kuldeep");
		driver.findElement(By.name("txtLN")).sendKeys("singh");
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		driver.findElement(By.name("DtOB")).sendKeys("28/08/1998");
		driver.findElement(By.name("Email")).sendKeys("ksinghch4@gmail.com");
		driver.findElement(By.name("Address")).sendKeys("Pune");
		Select drpCity=new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText("Mumbai");
		drpCity.selectByIndex(1);
		drpCity.selectByIndex(2);
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7500800149");
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		/*List<webElement> element=driver.findElement(By.name("chkHobbies")).sendKeys("Music");
		{
			val.click();
		}*/
	//}
		driver.findElement(By.name("submit")).sendKeys("Submit");
		driver.findElement(By.name("reset")).sendKeys("Reset");
}
}
