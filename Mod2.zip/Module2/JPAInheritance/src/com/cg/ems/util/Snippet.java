package com.cg.ems.util;

public class Snippet {
	private int empId;
}

