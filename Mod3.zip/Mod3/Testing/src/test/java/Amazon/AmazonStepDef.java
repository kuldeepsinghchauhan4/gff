package Amazon;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import AmazonBean.AmazonPageFactory;
import LoginPageBean.LoginPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AmazonStepDef {
	private WebDriver driver;
	private AmazonPageFactory ob;
	
	
	@Given("^User is on amazon login$")
	public void user_is_on_amazon_login() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ob= new  AmazonPageFactory(driver);
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fap%2Fcnep%3Fie%3DUTF8%26orig_return_to%3Dhttps%253A%252F%252Fwww.amazon.in%252Fyour-account%26openid.assoc_handle%3Dinflex%26pageId%3Dinflex&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		ob.setPfEmail("ksinghchauhan4@gmail.com");
		ob.setPfcont();
		ob.setPfpwd("28081998");
		ob.setPfbutton();
		
	   
	}

	@Then("^naviagate to welcome page$")
	public void naviagate_to_welcome_page() throws Throwable {
	  
		driver.navigate().to("file://ndafile/GLC-G102/BDD/Selenium/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000); 
	}

	@When("^user leaves  Email or mobile phone number blank$")
	public void user_leaves_Email_or_mobile_phone_number_blank() throws Throwable {
		ob.setPfEmail("");
		//Thread.sleep(1000);
		ob.setPfcont();

		ob.setPfpwd("");
		//Thread.sleep(1000);
		ob.setPfbutton();
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		ob.setPfbutton();
	}

	@Then("^display the alert msg$")
	public void display_the_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves Password  blank$")
	public void user_leaves_Password_blank() throws Throwable {
		ob.setPfEmail("ksinghchauhan4@gmail.com");
		//Thread.sleep(1000);
		ob.setPfcont();

		ob.setPfpwd("");
		//Thread.sleep(1000);
		ob.setPfbutton();
	}

	@When("^user is not giving valid credentials$")
	public void user_is_not_giving_valid_credentials() throws Throwable {
		ob.setPfEmail("kuyl");
		//Thread.sleep(1000);
		ob.setPfcont();

		ob.setPfpwd("123");
		//Thread.sleep(1000);
		ob.setPfbutton();
	}


}
