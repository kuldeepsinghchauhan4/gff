package HotelBooking;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBin.pageFactoryClass;

public class stepDef {
	private WebDriver driver;
	private pageFactoryClass object;
	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  object=new pageFactoryClass(driver);
	  driver.get("file://ndafile/GLC-G102/BDD/Selenium/hotelbooking.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	   String title=driver.getTitle();
	   if(title.contentEquals("HotelBooking"))
		   System.out.println("Title matched");
	   else
		   System.out.println("title not matched");
	   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	   driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	   object.setPffname("kuldeep"); Thread.sleep(1000);
	   object.setPflname("singh"); Thread.sleep(1000);
	   object.setPfemail("ksinghchasuhan4@gmail.com"); Thread.sleep(1000);
	   object.setPfmobile("75000800149"); Thread.sleep(1000);
	   object.setPfcity("Delhi"); Thread.sleep(1000);
	   object.setPfstate("Delhi"); Thread.sleep(1000);
	   object.setPfpersons(4); Thread.sleep(1000); Thread.sleep(1000);
	   object.setPfcardholdername("kuldeep singh"); Thread.sleep(1000);
	   object.setPfdebit("4514028103288740"); Thread.sleep(1000);
	   object.setPfcvv("275"); Thread.sleep(1000);
	   object.setPfmonth("07"); Thread.sleep(1000);
	   object.setPfyear("2025");
	   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	   object.setPfbutton();
	   driver.close();
	}

	@Then("^naviagate to welcome page$")
	public void naviagate_to_welcome_page() throws Throwable {
	  driver.navigate().to("file://ndafile/GLC-G102/BDD/Selenium/success.html");
	  driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	  driver.close();
	}

	@When("^user leaves first name blank$")
	public void user_leaves_first_name_blank() throws Throwable {
	  object.setPffname(""); Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	  object.setPfbutton();
	}

	@Then("^display the alert msg$")
	public void display_the_alert_msg() throws Throwable {
	   String alertMsg=driver.switchTo().alert().getText();
	   Thread.sleep(1000);
	   driver.switchTo().alert().accept();
	   System.out.println("****"+alertMsg);
	   driver.close();
	}

	@When("^user leaves last name blank and clicks the button$")
	public void user_leaves_last_name_blank_and_clicks_the_button() throws Throwable {
	   
		object.setPffname("kuldeep"); Thread.sleep(1000);
		object.setPflname(""); Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("Rutu.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005680");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(7);	Thread.sleep(1000);
		object.setPfcardholdername("Rutu Kulkarni");	Thread.sleep(1000);
		object.setPfdebit("7678567867897890");	Thread.sleep(1000);
		object.setPfcvv("056");	Thread.sleep(1000);
		object.setPfmonth("8");	Thread.sleep(1000);
		object.setPfyear("25");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
		object.setPfemail("Rk2@.com");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user leaves mobileno blank and clicks the button$")
	public void user_leaves_mobileno_blank_and_clicks_the_button(DataTable arg1) throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005480");	Thread.sleep(1000);
		object.setPfcity("Select City");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005480");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Select State");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user enters(\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005480");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(arg1);	Thread.sleep(2000);
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005480");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(7);	Thread.sleep(1000);
		object.setPfcardholdername("");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005480");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(7);	Thread.sleep(1000);
		object.setPfcardholdername("Rutuja Kulkarni");	Thread.sleep(1000);
		object.setPfdebit("");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("rutuja.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005680");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(7);	Thread.sleep(1000);
		object.setPfcardholdername("Rutuja Kulkarni");	Thread.sleep(1000);
		object.setPfdebit("8765431234567898");	Thread.sleep(1000);
		object.setPfcvv("098");	Thread.sleep(1000);
		object.setPfmonth("");	Thread.sleep(1000);
		object.setPfbutton();
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		object.setPffname("Rutuja");	Thread.sleep(1000);
		object.setPflname("Kulkarni");	Thread.sleep(1000);
		object.setPfemail("Rutu.k@gmail.com");	Thread.sleep(1000);
		object.setPfmobile("7722005680");	Thread.sleep(1000);
		object.setPfcity("Pune");	Thread.sleep(1000);
		object.setPfstate("Maharashtra");	Thread.sleep(1000);
		object.setPfpersons(7);	Thread.sleep(1000);
		object.setPfcardholdername("Rutu Kulkarni");	Thread.sleep(1000);
		object.setPfdebit("7678567867897890");	Thread.sleep(1000);
		object.setPfcvv("056");	Thread.sleep(1000);
		object.setPfmonth("8");	Thread.sleep(1000);
		object.setPfyear("");	Thread.sleep(1000);
		object.setPfbutton();
	}


}
