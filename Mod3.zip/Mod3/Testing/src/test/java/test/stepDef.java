package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	WebDriver driver;
	@Given("^Open th firefox and launch the application$")
	public void open_th_firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/GLC-G102/BDD/WorkingWithForms.html");
	   
	   
	}

	@When("^Enter the Username and Password$")
	public void enter_the_Username_and_Password() throws Throwable {
	   
		driver.findElement(By.id("txtUserName")).sendKeys("kuldeep12");
		driver.findElement(By.name("txtPwd")).sendKeys("igate");

		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		
	  
	}

	@Then("^Reset the redential$")
	public void reset_the_redential() throws Throwable {
	    
		driver.findElement(By.name("reset")).sendKeys("Reset");
		
	   
	}

 
}
