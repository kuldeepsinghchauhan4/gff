package com.cg.refundmoney.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.refundmoney.bean.Invoice;
import com.cg.refundmoney.bean.Orders;
import com.cg.refundmoney.bean.Product;
import com.cg.refundmoney.dao.IReturnDao;



@Service("service")
public class IReturnMoneySerImpl implements IReturnService {


	@Autowired
	public IReturnDao returnDao;
	
	@Autowired 
	public Orders orders;

	@Override
	public boolean refundMoney(int orderId)
	{
		return returnDao.refundMoney(orderId);
	}
}
		
	/*
	public boolean refundMoney(int order_id) {
		Invoice invoice = invoiceService.getInvoiceFromOrderId(orderId);
		Transaction transaction = transactionService.getTransactionFromInvoice(invoice);
		double transactionAmount = invoice.getDiscountedPrice();
		bankAccountService.withdrawAmount(transactionAmount, bankAccountService.getCapstoreBankAccount());
		if(transaction.getModeOfPayment().equals("NET_BANKING")) {
			
			bankAccountService.depositAmount(transactionAmount, bankAccountService.getBankAccount(transaction.getPaymentModeNumber()));
			return true;
			
		}else if(transaction.getModeOfPayment().equals("CARD")) {
			
			creditDebitService.depositAmount(transactionAmount, creditDebitService.getCardFromCardNumber(transaction.getPaymentModeNumber()));
			return true;
			
		}else if(transaction.getModeOfPayment().equals("CASH")) {
			return true;
		}else {
			return false;
		}
		
		
	}   
	  
     
		
		Product prod=new Product();
		Orders order=new Orders();
		Query prod1= em.createQuery("Select o.prod_id from orders_product o where o.order_id=:oid").setParameter("oid", order_id);
		Object pidf=prod1.getSingleResult();
		
          String or1=order.getOrderStatus();
          if(or1.equals("returned"))
          {
        	  if(order.getPaymentOptions().equals("NETBANKING")) {
           	  prod.getPrice();
           	  
        	  }
        	  
          }
          double price=prod.getPrice();
          orders.getOrder_id();
           String payment=order.getPaymentOptions();
       
       }
	*/


	
