package com.cg.maven.maven01_01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Maven0101Application {

	public static void main(String[] args) {
		SpringApplication.run(Maven0101Application.class, args);
	}

}
