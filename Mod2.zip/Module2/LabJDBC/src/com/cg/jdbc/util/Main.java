package com.cg.jdbc.util;

public class Main {

}
