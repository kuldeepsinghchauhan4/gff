package com.cg.refundmoney.service;

public interface IReturnService {
	public abstract boolean refundMoney(int orderId);
		

}
