package AmazonBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AmazonPageFactory {
	WebDriver driver;
	
	
@FindBy(name="email")
@CacheLookup
WebElement pfEmail;

@FindBy(name="password")
@CacheLookup
WebElement pfpwd;

@FindBy(id="signInSubmit")
@CacheLookup
WebElement pfbutton;

@FindBy(id="continue")
@CacheLookup
WebElement pfcont;



public AmazonPageFactory(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
}
	

public WebElement getPfEmail() {
	return pfEmail;
}

public void setPfEmail(String sEmail) {
	pfEmail.sendKeys(sEmail);
}

public WebElement getPfpwd() {
	return pfpwd;
}

public void setPfpwd(String spwd) {
	pfpwd.sendKeys(spwd);
}

public WebElement getPfbutton() {
	return pfbutton;
}

public void setPfbutton() {
	pfbutton.click();
}

public WebElement getPfcont() {
	return pfcont;
}


public void setPfcont() {
	pfcont.click();
}

}
