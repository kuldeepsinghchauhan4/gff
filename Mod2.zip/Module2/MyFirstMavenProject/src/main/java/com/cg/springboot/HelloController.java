package com.cg.springboot;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

}
