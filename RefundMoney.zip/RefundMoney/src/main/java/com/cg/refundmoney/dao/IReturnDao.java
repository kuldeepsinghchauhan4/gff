package com.cg.refundmoney.dao;

public interface IReturnDao {
	public abstract boolean refundMoney(int orderId);
}