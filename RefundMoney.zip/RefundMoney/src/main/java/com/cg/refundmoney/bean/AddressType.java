package com.cg.refundmoney.bean;

public enum AddressType 
{
	HOME,WORK
}
