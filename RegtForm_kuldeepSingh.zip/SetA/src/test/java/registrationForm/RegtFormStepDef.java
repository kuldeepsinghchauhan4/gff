package registrationForm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.RegistrationFormPageFactory;

public class RegtFormStepDef {
	
	private WebDriver driver;
	private RegistrationFormPageFactory object;
	
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "driver\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		object=new RegistrationFormPageFactory(driver);
		driver.get("file://ndafile/GLC-G102/BDD%20MPT%20HTML%20files/set%20A/WebPages/RegistrationForm.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Welcome to JobsWorld")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("123456"); Thread.sleep(1000);
	    object.setPfemail("kul@gmail.com"); Thread.sleep(1000);
	    object.setPfsex("Male"); Thread.sleep(1000);
	    object.setPfen("English"); Thread.sleep(1000);
	    object.setPfdesc("hie kuldeep singh"); Thread.sleep(1000);
	    object.setPfsubmit();
	}

	@Then("^close the driver$")
	public void click_on_submit_button() throws Throwable {
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user leaves userid empty$")
	public void user_leaves_userid_empty() throws Throwable {
		object.setPfuserID("");
	}

	@When("^clicks the submit button$")
	public void clicks_the_submit_button() throws Throwable {
		object.setPfsubmit();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user enter wrong length of user id$")
	public void user_enter_wrong_length_of_user_id() throws Throwable {
		object.setPfuserID("ab");
	}

	@When("^user leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd(""); Thread.sleep(1000);
	}

	@When("^user enter wrong length of password$")
	public void user_enters_all_data() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123"); Thread.sleep(1000);
	}

	@When("^user leaves Name empty$")
	public void user_leaves_Name_empty() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname(""); Thread.sleep(1000);
	}

	@When("^user enter wrong type of name$")
	public void user_enter_wrong_type_of_name() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("1245"); Thread.sleep(1000);
	}

	@When("^user leaves Address empty$")
	public void user_leaves_Address_empty() throws Throwable {
		object.setPfuserID("kuldjsd"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("kuld"); Thread.sleep(1000);
	    object.setPfaddr(""); Thread.sleep(1000);
	}

	@When("^user enter wrong type of address$")
	public void user_enter_wrong_type_of_address() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("a b s"); Thread.sleep(1000);
	}

	@When("^user not select any country$")
	public void user_not_select_any_country() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    //object.setPfcountry(""); Thread.sleep(1000);
	}

	@When("^user leaves zipcode empty$")
	public void user_leaves_zipcode_empty() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip(""); Thread.sleep(1000);
	}

	@When("^user enters wrong zipcode$")
	public void user_enters_wrong_zipcode() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("abc"); Thread.sleep(1000);
	}

	@When("^user leaves email empty$")
	public void user_leaves_email_empty() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("123456"); Thread.sleep(1000);
	    object.setPfemail(""); Thread.sleep(1000);
	}

	@When("^user enters wrong format of email id$")
	public void user_enters_wrong_format_of_email_id() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("123456"); Thread.sleep(1000);
	    object.setPfemail("absgsdg"); Thread.sleep(1000);
	}

	@When("^user does not select any gender$")
	public void user_does_not_select_any_gender() throws Throwable {
		object.setPfuserID("kulsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("123456"); Thread.sleep(1000);
	    object.setPfemail("kul@gmail.com"); Thread.sleep(1000);
	    object.setPfsex(""); Thread.sleep(1000);
	}

	@When("^select language$")
	public void select_language() throws Throwable {
		object.setPfuserID("kuldeepsingh"); Thread.sleep(1000);
	    object.setPfpwd("123456789"); Thread.sleep(1000);
	    object.setPfusrname("abcd"); Thread.sleep(1000);
	    object.setPfaddr("talwadepune"); Thread.sleep(1000);
	    object.setPfcountry("India"); Thread.sleep(1000);
	    object.setPfzip("123456"); Thread.sleep(1000);
	    object.setPfemail("kul@gmail.com"); Thread.sleep(1000);
	    object.setPfsex("Male"); Thread.sleep(1000);
	    object.setPfen("English"); Thread.sleep(1000);
	}

	@Then("^clicks the submit buttons$")
	public void clicks_the_submit_buttons() throws Throwable {
	    object.setPfsubmit();
	}
}
