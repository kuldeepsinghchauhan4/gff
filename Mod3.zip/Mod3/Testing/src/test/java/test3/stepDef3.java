package test3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef3 {
	WebDriver driver;
	@Given("^Open th firefox and launch the application$")
	public void open_th_firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Module3\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/GLC-G102/BDD/WorkingWithForms.html");
	}

	@When("^Enter the Username,Password,Confirm Password,First Name,Last Name,Gender,Date of Birth,Email,Address,City,Phone and Hobbies$")
	public void enter_the_Username_Password_Confirm_Password_First_Name_Last_Name_Gender_Date_of_Birth_Email_Address_City_Phone_and_Hobbies() throws Throwable {
		driver.findElement(By.id("txtUserName")).sendKeys("kuldeep12");
		driver.findElement(By.name("txtPwd")).sendKeys("igate");

		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("kuldeep");
		driver.findElement(By.name("txtLN")).sendKeys("singh");
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		driver.findElement(By.name("DtOB")).sendKeys("28/08/1998");
		driver.findElement(By.name("Email")).sendKeys("ksinghch4@gmail.com");
		driver.findElement(By.name("Address")).sendKeys("Pune");
		Select drpCity=new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText("Mumbai");
		drpCity.selectByIndex(1);
		drpCity.selectByIndex(2);
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7500800149");
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
	}

	@Then("^Reset the redential$")
	public void reset_the_redential() throws Throwable {
		driver.findElement(By.name("reset")).sendKeys("Reset");
	}
}
