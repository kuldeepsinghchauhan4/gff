package com.cg.refundmoney.dao;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cg.refundmoney.service.IReturnService;


@Transactional
@Repository("repo")
public class IReturnDaoImpl implements IReturnDao{

	@PersistenceContext
	EntityManager entityManager;


 public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean refundMoney(int orderId) {
		
		return false;
	}

}
